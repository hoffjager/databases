CREATE DATABASE Music_Catalogue

CREATE TABLE LP_Catalogue
(
	groupName varchar(50) NOT NULL,
	albumName varchar(50) NOT NULL PRIMARY KEY,
	yearReleased date NOT NULL,
	recordLabel varchar(50) NOT NULL,
	myRating int NOT NULL,
	genre varchar(50) NOT NULL
)

CREATE TABLE CD_Catalogue
(
	groupName varchar(50) NOT NULL,
	albumName varchar(50) NOT NULL,
	yearReleased date NOT NULL,
	recordLabel varchar(50) NOT NULL,
	myRating int NOT NULL,
	genre varchar(50) NOT NULL
)

INSERT INTO LP_Catalogue VALUES
('Simple Minds','New World Music','1982-06-01','WEA Records',8,'Pop'),
('U2','Rattle and Hum','1987-02-06','Geffen Records',7,'Pop'),
('Rick Astley','Rick Astley - Greatest Hits','1992-08-01','Warner Bros',6,'Pop'),
('ACDC','Live in Rio','1993-04-13','Warner Bros',7,'Rock')

INSERT INTO CD_Catalogue VALUES
('Meat Loaf','Bat out of Hell','1979-11-12','WEA Records',5,'Rock'),
('U2','Discotheque','2003-03-09','Warner Bros',7,'Pop'),
('Oasis','Greatest Hits','2012-03-24','Blue Records',7,'Pop'),
('ACDC','Greatest Hits - Vol 2','1999-09-09','Warner Bros',6,'Rock'),
('U2','Rattle and Hum','1987-02-06','Geffen Records',7,'Pop')

SELECT * FROM LP_Catalogue ORDER BY yearReleased

SELECT * FROM CD_Catalogue ORDER BY albumName

SELECT DISTINCT * FROM LP_Catalogue
UNION
SELECT DISTINCT * FROM CD_Catalogue

SELECT DISTINCT * FROM LP_Catalogue lp WHERE lp.myRating >= 7 
UNION
SELECT DISTINCT * FROM CD_Catalogue cd WHERE cd.myRating >= 7
ORDER BY myRating

SELECT DISTINCT * FROM LP_Catalogue lp WHERE lp.yearReleased > '1983-01-01'
UNION
SELECT DISTINCT * FROM CD_Catalogue cd WHERE cd.yearReleased > '1983-01-01'
ORDER BY yearReleased

CREATE TABLE Wish_List
(
	groupName varchar(50) NOT NULL,
	albumName varchar(50) NOT NULL PRIMARY KEY,
	yearReleased date NOT NULL,
	genre varchar(50) NOT NULL
)

INSERT INTO Wish_List VALUES
('Aztec Camera','Best of Aztec Camera','1997-09-14','Pop'),
('REM','Automatic for the People','1998-05-13','Pop'),
('U2','Rattle and Hum','1987-02-06','Pop'),
('Simple Minds','New World Music','1982-06-01','Pop')

SELECT * FROM Wish_List

SELECT albumName FROM Wish_List wl
EXCEPT
SELECT albumName FROM LP_Catalogue lp
ORDER BY albumName

SELECT albumName FROM Wish_List wl
EXCEPT
SELECT albumName FROM CD_Catalogue cd
ORDER BY albumName

SELECT albumName FROM Wish_List wl
INTERSECT
SELECT albumName FROM CD_Catalogue cd
ORDER BY albumName

SELECT albumName FROM Wish_List wl
INTERSECT
SELECT albumName FROM LP_Catalogue lp
ORDER BY albumName

SELECT albumName FROM CD_Catalogue cd
INTERSECT
SELECT albumName FROM LP_Catalogue lp
ORDER BY albumName

SELECT albumName FROM CD_Catalogue cd
EXCEPT
SELECT albumName FROM LP_Catalogue lp
ORDER BY albumName



















