CREATE DATABASE Quality_Software

CREATE TABLE Customers
(
	customerId int NOT NULL PRIMARY KEY,
	companyName varchar(50) NOT NULL,
	address1 varchar(50) NOT NULL,
	address2 varchar(50) NOT NULL,
	city varchar(50) NOT NULL,
	country varchar(50) NOT NULL,
	contactName varchar(50) NOT NULL,
	contactEmail varchar(50) NOT NULL
)

CREATE TABLE Contractors
(
	contractorId int NOT NULL PRIMARY KEY,
	firstName varchar(50) NOT NULL,
	lastName varchar(50) NOT NULL,
	address1 varchar(50) NOT NULL,
	address2 varchar(50) NOT NULL,
	city varchar(50) NOT NULL,
	country varchar(50) NOT NULL,
	contactPhone varchar(50) NOT NULL,
	contactEmail varchar(50) NOT NULL
)

INSERT INTO Customers VALUES
(1,'German Motors','22 Strabe Munchen','Munchen Klien','Munich','Deutscheland','Michael Schmidt','michaelschmidt@gmmotors.com'),
(2,'Das Auto','100 Munchen Business Park','Munchen 2323','Munich','Deutscheland','Philip Kroos','philipkroos@dasauto.com'),
(3,'Danone','15 Parkway House','Leicester Road','Leicester','England','Jamie Taylor','jamietaylor@danone.com'),
(4,'Nestle','13 Rue de Paris','Paris','Paris 201212','France','Michele Gaulle','michelegaulle@nestle.com')

SELECT * FROM Customers

INSERT INTO Contractors VALUES
(1,'Hans','Christian','12 Strabe Munchen','Munchen Klien','Munich','Deutscheland','4987565656','hanschristian@hotmail.com'),
(2,'Karl Heinz','Vakkel','10 New Forrest Strabe','Munchen Grob','Munich','Deutscheland','4987549543','karlheinz@hotmail.com'),
(3,'Anne','Leicester','54 Emmerdale Road','Emmerdale Farm','Emmerdale','England','055454545','anneleicester@hotmail.com'),
(4,'Peter','Rummeniege','13 Hamburg Way','Hamburg','Hamburg','Germany','4987545454','peterrummeniege@hotmail.com')

SELECT * FROM Contractors

UPDATE Contractors SET contactEmail = REPLACE(contactEmail,'karlheinz@hotmail.com','karlheinz@gmail.com') WHERE contractorId = 2

SELECT * FROM Contractors WHERE contractorId = 2

UPDATE Customers SET companyName = REPLACE(companyName,'Danone','Group Danone') WHERE customerId = 3

SELECT * FROM Customers WHERE customerId = 3

DELETE FROM Contractors WHERE contractorId = 3














