CREATE DATABASE theFizz

CREATE TABLE Employees
(
	ID int NOT NULL PRIMARY KEY,
	firstName varchar(70) NOT NULL,
	lastName varchar(70) NOT NULL,
	department varchar(30) NOT NULL,
	hireDate date NOT NULL,
	telephone varchar(15) NOT NULL,
	email varchar(100) NOT NULL
)

ALTER TABLE Employees ADD PPS_No varchar(10) NOT NULL

CREATE NONCLUSTERED INDEX lastNameEmployeesIndex ON Employees(lastName)

INSERT INTO Employees VALUES
(1,'Kevin','Phillips','IT','2022-01-05','013456456','kphillips@thefizz.com','5345615S'),
(2,'Jane','Wilson','HR','2022-01-02','013456632','jwilson@thefizz.com','9237119S')

SELECT * FROM Employees