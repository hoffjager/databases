CREATE DATABASE Doctors

CREATE TABLE Doctor_Details
(
	doctor_id int NOT NULL PRIMARY KEY,
	firstName varchar(50) NOT NULL,
	lastName varchar(50) NOT NULL,
	department varchar(50) NOT NULL,
	extensionNo int NOT NULL,
	onResearch int NOT NULL
)

INSERT INTO Doctor_Details VALUES
(1,'John','White','Eye, Ear and Throat','014569534',0),
(2,'Claire','Brown','Eye, Ear and Throat','014569535',0),
(3,'Gemma','Hayes','Eye, Ear and Throat','014569536',0),
(4,'Cian','Minnehan','Eye, Ear and Throat','014569537',0),
(5,'Declan','Moon','Eye, Ear and Throat','014569538',0)

SELECT * FROM Doctor_Details

CREATE TABLE Patient_Details
(
	patient_id int NOT NULL PRIMARY KEY,
	doctor_id int NOT NULL,
	firstName varchar(50) NOT NULL,
	lastName varchar(50) NOT NULL,
	phoneNo int NOT NULL,
	eMailAddress varchar(50) NOT NULL
)

INSERT INTO Patient_Details VALUES
(1,3,'Billy','McCarthy','01584754','bmaccarthy@hotmail.com'),
(2,4,'Anne','Manning','01583853','amanning@hotmail.com'),
(3,2,'Gerry','Newman','021434343','gnewman@hotmail.com'),
(4,1,'Amy','Dineen','01303023','adineen@hotmail.com'),
(5,5,'Ger','Walsh','021323232','gerwalsh@hotmail.com')

SELECT * FROM Patient_Details

SELECT d.doctor_id, d.firstName, d.lastName,
p.patient_id, p.firstName, p.lastName
FROM Doctor_Details d
INNER JOIN Patient_Details p
ON d.doctor_id = p.doctor_id
ORDER BY d.doctor_id

UPDATE Doctor_Details SET onResearch = REPLACE(onResearch,0,1)
WHERE doctor_id = 3

UPDATE Doctor_Details SET onResearch = REPLACE(onResearch,0,1)
WHERE doctor_id = 5

SELECT * FROM Doctor_Details

SELECT d.doctor_id, d.firstName, d.lastName, d.onResearch,
p.patient_id, p.firstName, p.lastName
FROM Doctor_Details d
INNER JOIN Patient_Details p
ON d.doctor_id = p.doctor_id
WHERE d.onResearch = 0
ORDER BY p.patient_id

SELECT d.doctor_id, d.firstName, d.lastName, d.onResearch,
p.patient_id, p.firstName, p.lastName
FROM Doctor_Details d
INNER JOIN Patient_Details p
ON d.doctor_id = p.doctor_id
WHERE d.onResearch = 1
ORDER BY p.patient_id













