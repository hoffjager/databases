CREATE DATABASE Football_Stickers_Collection

CREATE TABLE Football_Stickers
(
	ID int NOT NULL PRIMARY KEY,
	FirstName varchar(15) NOT NULL,
	LastName varchar(15) NULL,
	Country varchar(20) NOT NULL,
	CapsWon int NOT NULL
)

INSERT INTO Football_Stickers VALUES
(1,'Michel','Platini','France',86),
(2,'Diego','Maradona','Argentina',76),
(3,'Jordi','Cruyff','Netherlands',12),
(4,'Ossie','Ardiles','Argentina',48),
(5,'Paul','McGrath','Republic of Ireland',76),
(6,'John','Giles','Republic of Ireland',60),
(7,'Pele','','Brazil',89),
(8,'Zinedine','Zidane','France',76),
(9,'Liam','Brady','Republic of Ireland',88),
(10,'Leo','Messi','Argentina',95),
(11,'Craig','Bellamy','Wales',10),
(12,'George','Best','Northern Ireland',56),
(13,'Norman','Whiteside','Northern Ireland',30)
SELECT * FROM Football_Stickers

UPDATE Football_Stickers
SET FirstName = 'Johan' WHERE ID = 3

SELECT * FROM Football_Stickers WHERE ID = 3

DELETE FROM Football_Stickers WHERE ID = 11

SELECT * FROM Football_Stickers

DELETE FROM Football_Stickers WHERE Country = 'Northern Ireland'

SELECT * FROM Football_Stickers

INSERT INTO Football_Stickers VALUES
(11,'Emilio','Butragueno','Spain',67),
(12,'Hugo','Sanchez','Mexico',78)

SELECT * FROM Football_Stickers

SELECT * INTO Football_Stickers_Reserves
FROM Football_Stickers

SELECT * FROM Football_Stickers_Reserves

SELECT * INTO Irish_Football_Legends
FROM Football_Stickers
WHERE Country = 'Republic of Ireland'

SELECT * FROM Irish_Football_Legends




